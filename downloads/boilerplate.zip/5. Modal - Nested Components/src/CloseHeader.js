import templates from './CloseHeader.soy.js';
import Component from 'metal-component';
import Soy from 'metal-soy';

class CloseHeader extends Component {
}
Soy.register(CloseHeader, templates);

export default CloseHeader;
