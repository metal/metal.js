'use strict';

import Modal from '../src/index';

describe('Modal', function() {
	it('should be tested', function() {
		assert.fail('No tests for this module yet.');
	});
});
