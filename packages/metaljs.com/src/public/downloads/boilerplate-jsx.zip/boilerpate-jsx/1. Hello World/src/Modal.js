'use strict';

import JSXComponent from 'metal-jsx';

class Modal extends JSXComponent {
	render() {
		return <div>Hello World</div>;
	}
}

export default Modal;
