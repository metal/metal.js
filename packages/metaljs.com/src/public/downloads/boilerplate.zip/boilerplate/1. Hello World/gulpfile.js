'use strict';

var metal = require('gulp-metal');

metal.registerTasks({
	bundleCssFileName: 'modal.css',
	bundleFileName: 'modal.js',
	moduleName: 'metal-modal'
});
