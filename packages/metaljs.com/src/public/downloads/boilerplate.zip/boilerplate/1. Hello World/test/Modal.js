'use strict';

import Modal from '../src/Modal';

describe('Modal', function() {
	it('should be tested', function() {
		assert.fail('No tests for this module yet.');
	});
});
