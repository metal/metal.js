import templates from './CloseHeader.soy';
import Component from 'metal-component';
import Soy from 'metal-soy';

class CloseHeader extends Component {
}
Soy.register(CloseHeader, templates);

export default CloseHeader;
